public class AreaofRectangle
{
 public static void main(String[] args)
{
	int length=12,width=5,result;
	result=length*width;
	System.out.println("Area of Rectangle:"+result);
}
}