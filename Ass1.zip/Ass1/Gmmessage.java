public class Gmmessage{
public static void main(String[] args)
{
    int time=9;
	if(time>=6&&time<=12)
	{
	 System.out.println("Good morning");
	}
	else
	{
	System.out.println("Good Afternoon");
	}
	
}
}