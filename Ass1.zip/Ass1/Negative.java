public class Negative{
public static void main(String[] args)
{
    int no=-1;
	if(no<0)
	{
	 System.out.println("Number is Negetive");
	}
	else
	{
	System.out.println("Number is Positive");
	}
}
}