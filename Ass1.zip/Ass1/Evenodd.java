public class Evenodd{
public static void main(String[] args)
{
    int no=12;
	if(no%2==0)
	{
	 System.out.println("Number is Even");
	}
	else
	{
	System.out.println("Number is Odd");
	}
}
}