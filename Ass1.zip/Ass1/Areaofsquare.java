public class Areaofsquare
{
 public static void main(String[] args)
{
	int area=12,result;
	result=area*area;
	System.out.println("Area of Square:"+result);
}
}