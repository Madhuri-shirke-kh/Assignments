public class greater
{
 public static void main(String[] args)
{
	int a=9,b=15,c=5;
	if(a>=b&&a>=c)
	{
	System.out.println("A is greater:"+a);
	}
	if(b>=a&&b>=c)
	{
	System.out.println("B is greater:"+b);
	}
	if(a>=b&&a>=c)
	{
	System.out.println("C is greater:"+c);
	}
}
}