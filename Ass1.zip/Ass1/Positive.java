public class Positive{
public static void main(String[] args)
{
    int no=9;
	if(no>0)
	{
	 System.out.println("Number is positive:");
	}
	else
	{
	System.out.println("Number is Negetive");
	}
}
}